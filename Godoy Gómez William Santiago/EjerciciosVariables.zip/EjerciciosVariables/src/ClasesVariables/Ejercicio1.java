
package ClasesVariables;
public class Ejercicio1 {
    public static void main(String[] args) {
      String Nombre = "Michael";
        double x = 3.25;
        double dolar = 3851.22;
        float decimal = 3.1415926f; 
        double Euler = 2.718281828459045;
        System.out.println(Nombre);
        System.out.println(x);
        System.out.println(dolar);
        System.out.println(decimal);
        System.out.println(Euler);
    }
    
}
