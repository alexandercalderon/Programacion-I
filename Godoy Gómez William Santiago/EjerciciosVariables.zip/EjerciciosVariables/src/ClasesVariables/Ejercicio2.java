
package ClasesVariables;
public class Ejercicio2 {
    public static void main(String[] args) {
       int a = 8; 
       char b = 'A'; 
       String c = "Colombia"; 
       char d = 'A'; 
       float e = 74548f; 
       int numero = 1; 
       String nombrePersona = "Nuria"; 
       int edad = 18;
       String altura = "1.75";
       double alturaR = Double.parseDouble(altura);
       int doble = 96; 
       int A = 98; 
       char x = 'a'; 
       int y = 25; 
       char g = 'y'; 
        
       System.out.println(+a); 
       System.out.println("La variable b es: " +b); 
       System.out.println(c+ " es un pais muy bonito");      
       System.out.println("La variable d es: " +d); 
       System.out.println(+e); 
       System.out.println(+numero); 
       System.out.println(""+nombrePersona); 
       System.out.println("Tengo "+edad+ " años"); 
       System.out.println("Mido "+alturaR+ " cm"); 
       System.out.println(+doble); 
       System.out.println(+A); 
       System.out.println("La variable x es: "+x); 
       System.out.println(+y); 
       System.out.println("La variable g es: "+g);
       
    }
    
}
