
package sentenciasdecontrol;
public class DoWhile {
    public static void main(String[] args) {
      int contador = 1; 
        do 
        {
            System.out.println(" "+contador);
            ++contador; 
        } while (contador<=10);
        System.out.println();
  
    }
    
}
