
package sentenciasdecontrol;
public class While {
    public static void main(String[] args) {
       int producto = 3;
 
        
        while (producto <= 100)
        {
            producto = 3*producto;
        } 
    }
    
}
