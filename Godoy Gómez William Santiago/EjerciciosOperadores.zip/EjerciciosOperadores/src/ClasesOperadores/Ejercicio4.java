
package ClasesOperadores;
public class Ejercicio4 {
    public static void main(String[] args) {
        boolean Estado = (5 == 2)||(2 > 1);
        System.out.println("El resultado es: "+ Estado);
    }
    
}
