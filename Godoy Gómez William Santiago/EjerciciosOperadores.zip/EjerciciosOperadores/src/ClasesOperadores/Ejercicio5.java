
package ClasesOperadores;
public class Ejercicio5 {
    public static void main(String[] args) {
       double Resultado = ((2*50)+(7/2))-(-14*-2)/2;    
       System.out.println("((2*50)+(7/2))-(-14*-2)/2 = " +Resultado);
    
}
}