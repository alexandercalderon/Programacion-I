
package ClasesOperadores;
public class Ejercicio3 {
    public static void main(String[] args) {
       int numeroUno, numeroDos, aux;
       numeroUno = 8;
       numeroDos = 2;
       aux = numeroUno;
       numeroUno = numeroDos;
       numeroDos = aux;
      
       System.out.println("El valor de numeroUno es " +numeroUno);
       System.out.println("El valor de numeroDos es " +numeroDos);
      
       
    }
    
}
