
package ClasesOperadores;
public class Ejercicio2 {
    public static void main(String[] args) {
       int entero1 = 9;
        int entero2 = 7;
        int suma =entero1+ entero2;
        System.out.println("El resultado de la suma es: "+suma);
        int resta = entero1-entero2;
        System.out.println("El resultado de la resta es: "+resta);
        int multiplicacion = entero1*entero2;
        System.out.println("El resultado de la multiplicacion es: "+multiplicacion);
        double division = entero1/entero2;
        System.out.println("El resultado de la division es: "+division);
    }
    
}
