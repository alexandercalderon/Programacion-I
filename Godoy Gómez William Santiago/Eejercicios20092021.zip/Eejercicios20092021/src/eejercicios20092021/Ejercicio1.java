  
package eejercicios20092021;
    public class Ejercicio1 {
      public static void main(String[] args) {    
          
          System.out.println("Base y Exponente = " + Math.pow(5, 12));
        }
    
}
    

    
    