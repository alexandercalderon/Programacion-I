
package eejercicios20092021;
public class Ejercicio2 {
    public static void main(String[] args) {
         
        System.out.println("Raiz cuadrada de 2 es " + Math.sqrt(2));
        System.out.println("Raiz cuadrada de 8 es " + Math.sqrt(8));
        System.out.println("Raiz cuadrada de 27 es " + Math.sqrt(27));
        System.out.println("Raiz cuadrada de 28 es " + Math.sqrt(28));
        System.out.println("Raiz cuadrada de 55 es " + Math.sqrt(55));
        System.out.println("Raiz cuadrada de 121 es " + Math.sqrt(121));
        
    }
    
}
