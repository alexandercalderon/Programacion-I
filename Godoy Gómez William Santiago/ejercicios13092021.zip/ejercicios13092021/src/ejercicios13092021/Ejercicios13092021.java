
package ejercicios13092021;

public class Ejercicios13092021 {

    public static void main(String[] args) {
    int A = 5;
    int B = 3;
    int C = -12;
    boolean Decision1 = A>3;
    boolean Decision2 = A>C;
    boolean Decision3 = A<C;
    boolean Decision4 = B<C;
    boolean Decision5 = B!=C;
    boolean Decision6 = A==3;
    boolean Decision7 = A*B==15;
    boolean Decision8 = A*B==-30;
    boolean Decision9 = C/B<A;
    boolean Decision10 = C/B==-10;
    boolean Decision11 = C/B==-4;
    boolean Decision12 = A+B+C==5;
    boolean Decision13 =(A+B==8)&&(A-B==2);
    boolean Decision14 =(A+B==8)||(A-B==6);
    boolean Decision15 = A>3&&B>3&&C<3;
    boolean Decision16 = A>3&&B>=3&&C<-3;
              
    System.out.println("La expresion 1 daria como resultado: "+Decision1);
    System.out.println("La expresion 2 daria como resultado: "+Decision2);
    System.out.println("La expresion 3 daria como resultado: "+Decision3);
    System.out.println("La expresion 4 daria como resultado: "+Decision4);
    System.out.println("La expresion 5 daria como resultado: "+Decision5);
    System.out.println("La expresion 6 daria como resultado: "+Decision6);
    System.out.println("La expresion 7 daria como resultado: "+Decision7);
    System.out.println("La expresion 8 daria como resultado: "+Decision8);
    System.out.println("La expresión 9 daria como resultado: "+Decision9);
    System.out.println("La expresión 10 daria como resultado: "+Decision10);
    System.out.println("La expresión 11 daria como resultado: "+Decision11);
    System.out.println("La expresión 12 daria como resultado: "+Decision12);
    System.out.println("La expresión 13 daria como resultado: "+Decision13);
    System.out.println("La expresión 14 daria como resultado: "+Decision14);
    System.out.println("La expresión 15 daria como resultado: "+Decision15);
    System.out.println("La expresión 16 daria como resultado: "+Decision16);
    
  
    }
    
}
