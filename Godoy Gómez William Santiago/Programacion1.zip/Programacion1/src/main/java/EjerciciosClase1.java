
public class EjerciciosClase1 {

    public static void main(String[] args) {
    long numero1 = 8;
    long numero3 = 3;
    double numero5 = 7.6;
    float numero7 = 2.3F;
    int numero2 = 3;
    int numero4 = 52;
    int numero6 = 4;
    int numero8 = 5;
    
    long resta = numero1-numero2;
    long suma = numero3+numero4;
    double multiplicacion = numero5*numero6;
    float division = numero7/numero8;
    System.out.println("El resultado de la resta es "+resta);
    System.out.println("El resultado de la suma es "+suma);
    System.out.println("El resultado de la multiplicación es "+multiplicacion);
    System.out.println("El resultado de la división es "+division);
    

    
    
   
    

    }
    
}
