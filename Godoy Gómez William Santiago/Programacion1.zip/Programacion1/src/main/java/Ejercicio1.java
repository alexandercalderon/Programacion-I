
public class Ejercicio1 {
    
    public static void main(String[] args) {
        int N = 5;
        double A = 4.56;
        char C = 'a';
        System.out.println("Variable N = " + N);
        System.out.println("Variable A = " + A);
        System.out.println("Variable C = " + C);
        System.out.println(N + " + " + A + " = " + (N+A));
        System.out.println(A + " - " + N + " = " + (A-N));
        System.out.println("Valor numérico del carácter " + C + " = " + (int)C);
    }
    
}
