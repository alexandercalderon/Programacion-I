
package ejercicios14092021;



public class Ejercicios14092021 {


    public static void main(String[] args) {
        
        int A = 5, B = 3, C = -12; 
        
        boolean desicion1 = A>3;
        boolean desicion2 = A>C;
        boolean desicion3 = A<C;
        boolean desicion4 = B<C;
        boolean desicion5 = B!=C;
        boolean desicion6 = A==3;
        boolean desicion7 = A*B==15;
        boolean desicion8 = A*B==-30;
        boolean decision9 = C/B<A; 
        boolean decision10 = C/B==-10; 
        boolean decision11 = C/B==-4; 
        boolean decision12 = A+B+C==5;
        boolean decision13 =(A+B==8)&&(A-B==2); 
        boolean decision14 =(A+B==8)||(A-B==6); 
        boolean decision15 = A>3&&B>3&&C<3; 
        boolean decision16 = A>3&&B>=3&&C<-3;
        System.out.println("La expresion 1 daria como resultado: "+desicion1);
        System.out.println("La expresion 2 daria como resultado: "+desicion2);
        System.out.println("La expresion 3 daria como resultado: "+desicion3);
        System.out.println("La expresion 4 daria como resultado: "+desicion4);
        System.out.println("La expresion 5 daria como resultado: "+desicion5);
        System.out.println("La expresion 6 daria como resultado: "+desicion6);
        System.out.println("La expresion 7 daria como resultado: "+desicion7);
        System.out.println("La expresion 8 daria como resultado: "+desicion8);
        System.out.println("La expresión 9 daria como resultado: "+decision9); 
        System.out.println("La expresión 10 daria como resultado: "+decision10); 
        System.out.println("La expresión 11 daria como resultado: "+decision11); 
        System.out.println("La expresión 12 daria como resultado: "+decision12); 
        System.out.println("La expresión 13 daria como resultado: "+decision13); 
        System.out.println("La expresión 14 daria como resultado: "+decision14); 
        System.out.println("La expresión 15 daria como resultado: "+decision15); 
        System.out.println("La expresión 16 daria como resultado: "+decision16);


    }



    }
    
