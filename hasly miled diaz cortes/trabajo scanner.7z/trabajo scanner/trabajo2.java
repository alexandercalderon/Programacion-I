
public class trabajo2 {
   public static void main (string[] args){
       double Saldo = 100000
               double saldot;
               
               Scanner sc= new Scanner (System.in);
               System.out.println ("ingresa tu nombre");
               String Nombre = sc.nextline() ;
               
               double retiro;
               Scanner rt = new Scanner(System.in);
               System.out.println ("cuanto dinero desea retirar:");
               retiro = sc.netxDouble ();
               
               
              saldot= saldo=retiro;
              
              
              System.out.println("saldo:" +saldot);
                       
               
   } 
}
