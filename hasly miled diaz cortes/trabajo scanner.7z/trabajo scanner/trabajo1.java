
public class trabajo1 {
    public static void main (string[] args){
        Scanner teclado = new Scanner (System.in)
        string nombre;
        double radio;
        int n;
        
        System.out.println("introduzca su nombre:");
        nombre = teclado.nextLine();//leer un string
        System.out.println("el nombre digitado es:"+nombre);
        
        System.out.println("introduzca el radiode la circunferencia:");
        radio= teclado.nextDouble();
        System.out.println("longitud de la circunferencia:" +2*math.PI*radio);
        
        System.out.println("introduzca un numero entero:");
        n= teclado.nextlnt();
        System.out.println("el cuadrado es:"+ math.pow(n,2));
        
      
    
}