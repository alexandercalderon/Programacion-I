package Trabajoscanner2;
import java.util.Scanner;
        
public class Ejercicio1 {
    public static void main (String [] args){
        Scanner teclado= new Scanner (System.in);
        int Base ;
        int Exponente = 0 ;
        
        System.out.println("digite el valor de la base:");
        Base= teclado.nextInt();
        System.out.println("la respuesta es:" + Math.pow(Base, Exponente));
        
                
            
    }
    
}
