package trabajoscanner2;
import java.util.Scanner;
public class ejercicio3 {
   public static void main ( String[] args){
       Scanner num = new
       Scanner(System.in);
       double nota1;
       double nota2;
       double nota3;
       double nota4;
       double nota5;
       double promedio;
       
       System.out.println("escriba el valor de la nota 1");
       nota1 = num.nextDouble();
       System.out.println("");
       
       System.out.println("escriba el valor de la nota 2");
       nota2 = num.nextDouble();
       System.out.println("");
       
      System.out.println("escriba el valor de la nota 3");
      nota3 = num.nextDouble();
      System.out.println("");
      
      System.out.println("escriba el valor de la nota 4");
      nota4 = num.nextDouble();
      System.out.println("");
      
      System.out.println("escriba el valor de la nota 5");
      nota5 = num.nextDouble();
      System.out.println("");
      
      promedio = (nota1+nota2+nota3+nota4+nota5)/5;
      
      System.out.println("el promedio es:"+ promedio);
   
   } 
}
