package trabajoscanner2;
import java.util.Scanner

public class ejercicio2 {
    public static void main (string[]args){
        Scanner leer =new Scanner(System.in)
                int raiz1;
                int raiz2;
                int raiz3;
                int raiz4;
                int raiz5;
                int raiz6;
                int raiz7;
           System.out.println("digite el valor de raiz1:");
           raiz1 = leer.nextInt();
           System.out.println("");
           
           System.out.println("digite el valor de raiz2:");
           raiz2 = leer.nextInt();
           System.out.println("");
           
           System.out.println("digite el valor de raiz3:");
           raiz3 = leer.nextInt();
           System.out.println("");
           
           System.out.println("digite el valor de raiz4:");
           raiz4= leer.nextInt();
           System.out.println("");
           
           System.out.println("digite el valor de raiz5:");
           raiz5= leer.nextInt();
           System.out.println("");
           
           System.out.println("digite el valor de raiz6:");
           raiz6= leer.nextInt();
           System.out.println("");
           
           System.out.println("digite el valor d raiz7:");
           raiz7= leer.nextInt();
           System.out.println("");
           
           
           System.out.println ("raiz cuadrada de "+raiz1+" es:" + Math.sqrt(raiz1));
           System.out.println("raiz cuadrada de "+raiz2+" es:"+ Math.sqrt (raiz2));
           System.out.println("raiz cuadrada de"+raiz3+" es:"+ Math.sqrt (raiz3));
           System.out.println("raiz cuadrada de"+raiz4+" es:"+ Math.sqrt(raiz4));
           System.out.println("raiz cuadrada de"+raiz5+"es:"+ Math.sqrt(raiz5));
           System.out.println("raiz cuadrada de"+raiz6+" es:"+ Math.sqrt(raiz6));
           System.out.println("raiz cuadrada de"+raiz7+"es:"+ Math.sqrt(raiz7));
           
           
    }
            }
